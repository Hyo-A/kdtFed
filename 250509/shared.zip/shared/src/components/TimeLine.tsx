import { useState, useEffect } from "react";
import { query, collection, orderBy, getDocs } from "firebase/firestore";
import { db } from "../firebase";

interface ITweet {
  createdAt: number;
  photo?: string;
  video?: string;
  tweet: string;
  userId: string;
  username: string;
}

const TimeLine = () => {
  const [tweets, setTweets] = useState<ITweet[]>([]);
  const fetchTweets = async () => {
    const tweetsQuery = query(
      collection(db, "tweets"),
      orderBy("createdAt", "desc")
    );
    const snapshot = await getDocs(tweetsQuery);
    snapshot.docs.forEach((doc) => console.log(doc.data()));
  };
  useEffect(() => {
    fetchTweets();
  }, []);

  return <div>{JSON.stringify(tweets)}</div>;
};

export default TimeLine;
